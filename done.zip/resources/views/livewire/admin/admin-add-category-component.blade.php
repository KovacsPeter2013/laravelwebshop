<div>
   <div class="container" style="padding: 30px 0;">
   	
   	<div class="row">
   		<div class="col-md-12">
   			<div class="panel panel-default">
   				<div class="panel-heading">
   					 <div class="row">
   					 	<div class="col-md-6">
   					 		Új kategória hozzáadás
   					 	</div>
   					 	<div class="col-md-6">
   					 		<a href="{{route('admin.categories')}}" class="btn btn-success pull-right">Minden kategória</a>
   					 	</div>
   					 </div>	
   				</div>

   				<div class="panel-body">
   					@if(Session::has('messages'))

   						<div class="alert alert-success" role="alert">{{Session::get('messages')}}</div>

   					@endif
   					<form class="form-horizontal" wire:submit.prevent="storeCategory">
   						<div class="form-group">
   							<label class="col-md-4 control-label">Kategória neve</label>
   							<div class="col-md-4">
   								<input type="text" name="" placeholder="Kategória neve" class="form-control input-md" wire:model="name" wire:keyup="generateslug">

                           @error('name') <p class="text-danger">{{$message}}</p> @enderror
   							</div> 
   						</div>

   						<div class="form-group">
   							<label class="col-md-4 control-label">Kategória slug</label>
   							<div class="col-md-4">
   								<input type="text" name="" placeholder="Kategória Slug" class="form-control input-md"wire:model="slug">
                           @error('slug') <p class="text-danger">{{$message}}</p> @enderror
   							</div>
   						</div>




                     <div class="form-group">
                        <label class="col-md-4 control-label">Parent kategória</label>
                        <div class="col-md-4">
                           
                         <select class="form-control input-md" wire:model="category_id">
                            <option value="">None</option>

                            @foreach($categories as $category)

                              <option value="{{$category->id}}">{{$category->name}}</option>

                            @endforeach

                         </select>
                        </div>
                     </div>



   								<div class="form-group">
   							<label class="col-md-4 control-label"></label>
   							<div class="col-md-4">
   								<button type="submit" class="btn btn-primary">Elküldés</button>
   							</div>
   						</div>
   					</form>
   				</div>
   			</div>
   		</div>
   	</div>
   </div>
</div>
