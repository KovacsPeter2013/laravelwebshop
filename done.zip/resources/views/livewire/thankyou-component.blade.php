	<main id="main" class="main-site">

		<div class="container">

			<div class="wrap-breadcrumb">
				<ul>
					<li class="item-link"><a href="/" class="link">Kezdőlap</a></li>
					<li class="item-link"><span>Köszönjük</span></li>
				</ul>
			</div>
		</div>
		
		<div class="container pb-60">
			<div class="row">
				<div class="col-md-12 text-center">
					<h2>Köszönjük a rendelést</h2>
                    <p>A rendelésről emailt küldtünk a megadott címre</p>
                    <a href="/shop" class="btn btn-submit btn-submitx">Vásárlás folytatása</a>
				</div>
			</div>
		</div>

	</main>
